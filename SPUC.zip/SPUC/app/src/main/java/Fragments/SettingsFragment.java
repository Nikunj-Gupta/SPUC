package Fragments;
import android.support.v4.app.Fragment;

/**
 * Created by ABHIJNU on 10/22/2016.
 */
public class SettingsFragment extends Fragment {
}
