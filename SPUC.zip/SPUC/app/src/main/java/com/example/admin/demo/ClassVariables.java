package com.example.admin.demo;

/**
 * Created by Nikunj on 22-10-2016.
 */
public class ClassVariables {
    public static final String IP = "http://172.16.82.6:8080";

    public static final String REGISTER_URL = IP + "/rto/insert.php";
    public static final String LOGIN_URL = IP + "/rto/login.php";
    public static final String ALERT_URL = IP + "/rto/update_check_CO.php";



    public static final String KEY_V_ID = "vid";
    public static final String KEY_S_ID = "sid";
    public static final String KEY_NAME = "name";
    public static final String KEY_PHONE = "phone";
    public static final String KEY_ADDRESS = "address";
    public static final String KEY_CO = "co_percent";






}
