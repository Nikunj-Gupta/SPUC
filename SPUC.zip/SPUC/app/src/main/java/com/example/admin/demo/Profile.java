package com.example.admin.demo;

/**
 * Created by Nikunj on 23-10-2016.
 */
public class Profile {

    public static String Vehicle = "";
    public static String Sensor  = "";
    public static String Name = "";
    public static String Phone = "";
    public static String Address = "";

    public static String Data = "";
    public static String CO_DATA = "";



}
